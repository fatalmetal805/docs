#include "pch.h"

#ifndef _LINK_WITH_CPPRESTSDK
#include "cpprestsdk_impl.h"
#endif