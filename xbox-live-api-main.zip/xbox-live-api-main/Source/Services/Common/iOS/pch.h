// Copyright (c) Microsoft Corporation
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#pragma once
#define _LIBCPP_ENABLE_CXX17_REMOVED_AUTO_PTR

#include "Unix/pch.h"

#define XSAPI_I 1
