// Copyright (c) Microsoft Corporation
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "pch.h"

#ifndef _LINK_WITH_CPPRESTSDK
#include "cpprestsdk_impl.h"
#endif
