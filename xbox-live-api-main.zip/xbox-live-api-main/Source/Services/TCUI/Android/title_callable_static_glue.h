#pragma once
bool title_callable_ui_register_natives(JNIEnv *env, jobject clsLoader, jmethodID loadClass);