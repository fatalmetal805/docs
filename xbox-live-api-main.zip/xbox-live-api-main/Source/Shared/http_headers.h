// Copyright (c) Microsoft Corporation
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#pragma once

NAMESPACE_MICROSOFT_XBOX_SERVICES_CPP_BEGIN

typedef xsapi_internal_map<xsapi_internal_string, xsapi_internal_string> xsapi_internal_http_headers;

NAMESPACE_MICROSOFT_XBOX_SERVICES_CPP_END