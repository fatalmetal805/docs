// Copyright (c) Microsoft Corporation
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "pch.h"
#include "xsapi-cpp/mem.h"
#include "xsapi-cpp/system.h"

NAMESPACE_MICROSOFT_XBOX_SERVICES_SYSTEM_CPP_BEGIN



NAMESPACE_MICROSOFT_XBOX_SERVICES_SYSTEM_CPP_END
