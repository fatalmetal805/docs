#pragma once

extern bool http_call_register_natives(JNIEnv *env, jobject clsLoader, jmethodID loadClass);

