#pragma once

extern bool xbox_live_app_config_register_natives(JNIEnv *env, jobject clsLoader, jmethodID loadClass);

