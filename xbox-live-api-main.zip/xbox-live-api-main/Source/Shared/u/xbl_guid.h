// Copyright (c) Microsoft Corporation
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#pragma once

#include "pch.h"

NAMESPACE_MICROSOFT_XBOX_SERVICES_CPP_BEGIN

xsapi_internal_string generate_guid();

NAMESPACE_MICROSOFT_XBOX_SERVICES_CPP_END