// Copyright (c) Microsoft Corporation
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
#include "pch_common.h"
#if HC_PLATFORM != HC_PLATFORM_IOS
#include <rapidjson/allocators.hpp>
#endif